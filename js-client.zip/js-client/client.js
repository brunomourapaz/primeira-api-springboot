function consultarRestaurantes() {
  $.ajax({
    url: "http://api.futurodev.com:8000/usuarios",
    type: "get",

    success: function(response) {
      $("#conteudo").text(JSON.stringify(response));
    }
  });
}

$("#botao").click(consultarRestaurantes);